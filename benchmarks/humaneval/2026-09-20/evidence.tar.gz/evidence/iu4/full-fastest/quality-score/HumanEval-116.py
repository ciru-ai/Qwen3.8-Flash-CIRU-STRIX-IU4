        # For negative numbers, we need to handle them differently.
        # The problem states "non-negative integers" but the example includes negatives.
        # Looking at the example: sort_array([-2, -3, -4, -5, -6]) == [-6, -5, -4, -3, -2]
        # This suggests that for negative numbers, we just sort by decimal value.
        # But let's think about what "number of ones in binary representation" means for negatives.
        # In Python, bin(-2) gives '-0b10', which has 1 one. bin(-3) gives '-0b11', which has 2 ones.
        # If we count ones in the absolute value's binary representation:
        # -2: abs=2, bin='10', ones=1
        # -3: abs=3, bin='11', ones=2
        # -4: abs=4, bin='100', ones=1
        # -5: abs=5, bin='101', ones=2
        # -6: abs=6, bin='110', ones=2
        # Sorting by (ones, value): 
        # -2: (1, -2), -4: (1, -4) -> -4 comes before -2? No, -4 < -2, so -4 first.
        # -3: (2, -3), -5: (2, -5), -6: (2, -6) -> -6, -5, -3
        # So result would be [-4, -2, -6, -5, -3] which doesn't match [-6, -5, -4, -3, -2].
        
        # The expected output [-6, -5, -4, -3, -2] is just sorted by decimal value ascending.
        # This suggests that for negative numbers, we might just sort by value, or the problem
        # intends that we only apply the ones-count sorting for non-negative numbers.
        
        # Let me re-read: "sort an array of non-negative integers" but the example has negatives.
        # Perhaps the intent is: if all are non-negative, sort by ones then value. If negatives exist, 
        # maybe just sort by value? Or perhaps the ones count for negatives is defined differently.
        
        # Another interpretation: maybe for negative numbers, we consider their two's complement?
        # That gets complicated. Let's look at the expected output again: [-6, -5, -4, -3, -2]
        # This is simply sorted ascending by decimal value.
        
        # Perhaps the simplest approach: sort by (number of ones in binary of abs(n), n) for non-negative,
        # and for negative numbers, just sort by n. But that would mix them oddly.
        
        # Actually, looking more carefully, maybe the problem just wants us to sort by (count_ones, value)
        # where count_ones is computed on the absolute value, and for ties, sort by value.
        # Let's test: 
        # -6: abs=6, bin=110, ones=2, key=(2, -6)
        # -5: abs=5, bin=101, ones=2, key=(2, -5)
        # -4: abs=4, bin=100, ones=1, key=(1, -4)
        # -3: abs=3, bin=11, ones=2, key=(2, -3)
        # -2: abs=2, bin=10, ones=1, key=(1, -2)
        # Sorted by key: (1,-4), (1,-2), (