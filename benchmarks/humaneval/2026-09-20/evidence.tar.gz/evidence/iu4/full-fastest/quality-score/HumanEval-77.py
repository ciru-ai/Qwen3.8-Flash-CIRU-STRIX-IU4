def iscube(a):
    '''
    Write a function that takes an integer a and returns True 
    if this ingeger is a cube of some integer number.
    Note: you may assume the input is always valid.
    Examples:
    iscube(1) ==> True
    iscube(2) ==> False
    iscube(-1) ==> True
    iscube(64) ==> True
    iscube(0) ==> True
    iscube(180) ==> False
    '''
    # Handle negative numbers by taking absolute value and checking sign
    if a < 0:
        a = -a
        sign = -1
    else:
        sign = 1
    
    # Find the cube root approximately
    if a == 0:
        return True
    
    # Compute cube root using round
    cube_root = round(a ** (1/3))
    
    # Check if cube_root^3 equals a
    if cube_root ** 3 == a:
        return True
    # Also check nearby integers due to floating point issues
    for candidate in [cube_root - 1, cube_root, cube_root + 1]:
        if candidate ** 3 == a:
            return True
    
    return False