def largest_divisor(n: int) -> int:
    """ For a given number n, find the largest number that divides n evenly, smaller than n
    >>> largest_divisor(15)
    5
    """
    # The largest divisor of n (smaller than n) is n divided by its smallest prime factor.
    # So we find the smallest divisor d > 1, then return n // d.
    if n <= 1:
        return 1  # Edge case, though problem likely assumes n > 1
    
    # Find the smallest divisor greater than 1
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return n // i
    
    # If no divisor found, n is prime, so the largest divisor smaller than n is 1
    return 1