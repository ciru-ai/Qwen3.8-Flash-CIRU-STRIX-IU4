def get_closest_vowel(word):
    """You are given a word. Your task is to find the closest vowel that stands between 
    two consonants from the right side of the word (case sensitive).
    
    Vowels in the beginning and ending doesn't count. Return empty string if you didn't
    find any vowel met the above condition. 

    You may assume that the given string contains English letter only.

    Example:
    get_closest_vowel("yogurt") ==> "u"
    get_closest_vowel("FULL") ==> "U"
    get_closest_vowel("quick") ==> ""
    get_closest_vowel("ab") ==> ""
    """
    vowels = set('aeiouAEIOU')
    
    # We need to find a vowel that is between two consonants.
    # "From the right side" means we should search from the end towards the beginning.
    # The vowel cannot be at the beginning or end of the word.
    
    # Iterate from the second-to-last character down to the second character (index 1 to len-2)
    for i in range(len(word) - 2, 0, -1):
        if word[i] in vowels:
            # Check if the characters before and after are consonants (not vowels)
            if word[i - 1] not in vowels and word[i + 1] not in vowels:
                return word[i]
    
    return ""