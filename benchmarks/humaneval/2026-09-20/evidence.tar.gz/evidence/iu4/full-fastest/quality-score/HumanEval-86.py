def anti_shuffle(s):
    """
    Write a function that takes a string and returns an ordered version of it.
    Ordered version of string, is a string where all words (separated by space)
    are replaced by a new word where all the characters arranged in
    ascending order based on ascii value.
    Note: You should keep the order of words and blank spaces in the sentence.

    For example:
    anti_shuffle('Hi') returns 'Hi'
    anti_shuffle('hello') returns 'ehllo'
    anti_shuffle('Hello World!!!') returns 'Hello !!!Wdlor'
    """
    if not s:
        return s
    
    # Split the string by spaces, but we need to preserve the exact spacing
    # The problem says "separated by space" and "keep the order of words and blank spaces"
    # Looking at the example: 'Hello World!!!' -> 'Hello !!!Wdlor'
    # 'Hello' sorted by ASCII: 'Hello' -> H(72), e(101), l(108), l(108), o(111) -> 'Hello' (already sorted? No, H < e < l < l < o, so 'Hello' is already in ascending ASCII order)
    # 'World!!!' sorted by ASCII: !(33), !(33), !(33), W(87), o(111), r(114), d(100) -> wait, let me sort properly
    # Characters in 'World!!!': W, o, r, l, d, !, !, !
    # ASCII values: W=87, o=111, r=114, l=108, d=100, !=33, !=33, !=33
    # Sorted: !, !, !, W, d, l, o, r -> '!!!Wdlor'
    # So the result is 'Hello !!!Wdlor' which matches.
    
    # We need to split by spaces while preserving the structure.
    # Let's split by space and rejoin with space.
    words = s.split(' ')
    sorted_words = []
    for word in words:
        sorted_word = ''.join(sorted(word))
        sorted_words.append(sorted_word)
    
    return ' '.join(sorted_words)