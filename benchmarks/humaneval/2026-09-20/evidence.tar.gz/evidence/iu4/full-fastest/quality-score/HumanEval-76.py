def is_simple_power(x, n):
    """Your task is to write a function that returns true if a number x is a simple
    power of n and false in other cases.
    x is a simple power of n if n**int=x
    For example:
    is_simple_power(1, 4) => true
    is_simple_power(2, 2) => true
    is_simple_power(8, 2) => true
    is_simple_power(3, 2) => false
    is_simple_power(3, 1) => false
    is_simple_power(5, 3) => false
    """
    # Handle edge cases
    if n == 1:
        return x == 1
    if n == 0:
        return x == 0 or x == 1  # 0^0 is sometimes defined as 1, but let's check: 0**0=1, 0**1=0, etc.
    
    # For negative n, we need to be careful with integer powers
    # Let's handle positive n first, then negative
    
    if n > 0:
        # Check if x is a power of n
        if x == 1:
            return True  # n^0 = 1 for any n != 0
        if x <= 0:
            return False  # positive base raised to any integer power is positive (except 0^0 handled above)
        
        # Repeatedly divide x by n and check if we end up with 1
        current = x
        while current % n == 0:
            current //= n
        return current == 1
    else:
        # n is negative
        # n^k can be positive or negative depending on k
        if x == 1:
            return True  # n^0 = 1
        if x == 0:
            return False  # negative base raised to any integer power is never 0
        
        # Check if |x| is a power of |n|
        abs_n = abs(n)
        abs_x = abs(x)
        
        if abs_x == 1:
            return True  # n^0 = 1
        
        current = abs_x
        while current % abs_n == 0:
            current //= abs_n
        
        if current != 1:
            return False
        
        # Now we know |x| = |n|^k for some k >= 1
        # We need to check if x = n^k for some integer k
        # n^k = (-1)^k * |n|^k
        # So x = (-1)^k * abs_x
        # This means if x > 0, k must be even; if x < 0, k must be odd
        
        # Find k such that |n|^k = abs_x
        k = 0
        temp = 1
        while temp < abs_x:
            temp *= abs_n
            k += 1
        
        if temp != abs_x:
            return False
        
        # Check parity
        if x > 0:
            return k % 2 == 0
        else:
            return k % 2 == 1