import math
def poly(xs: list, x: float):
    """
    Evaluates polynomial with coefficients xs at point x.
    return xs[0] + xs[1] * x + xs[1] * x^2 + .... xs[n] * x^n
    """
    return sum([coeff * math.pow(x, i) for i, coeff in enumerate(xs)])
def find_zero(xs: list):
    """ xs are coefficients of a polynomial.
    find_zero find x such that poly(x) = 0.
    find_zero returns only only zero point, even if there are many.
    Moreover, find_zero only takes list xs having even number of coefficients
    and largest non zero coefficient as it guarantees
    a solution.
    >>> round(find_zero([1, 2]), 2) # f(x) = 1 + 2x
    -0.5
    >>> round(find_zero([-6, 11, -6, 1]), 2) # (x - 1) * (x - 2) * (x - 3) = -6 + 11x - 6x^2 + x^3
    1.0
    """
    # The problem states that xs has an even number of coefficients.
    # This means the polynomial has odd degree (since degree = len(xs) - 1).
    # An odd-degree polynomial with real coefficients always has at least one real root.
    # We can use a numerical method like bisection to find a root.
    
    # First, let's determine the degree of the polynomial
    degree = len(xs) - 1
    
    # We need to find bounds for the root. Let's start with a wide range and expand if needed.
    # For a polynomial with leading coefficient a_n, the roots are bounded by 
    # 1 + max(|a_i/a_n|) for i < n (Cauchy's bound)
    
    # Find the leading coefficient (last non-zero coefficient)
    # Actually, the problem says "largest non zero coefficient" but I think it means the leading coefficient is non-zero.
    # Let's just use the last element as the leading coefficient.
    
    # Cauchy's bound: all roots satisfy |x| <= 1 + max(|a_i / a_n|) for i = 0 to n-1
    leading_coeff = xs[-1]
    if leading_coeff == 0:
        # Find the actual leading coefficient
        for i in range(len(xs) - 1, -1, -1):
            if xs[i] != 0:
                leading_coeff = xs[i]
                break
    
    max_ratio = 0
    for i in range(len(xs) - 1):
        max_ratio = max(max_ratio, abs(xs[i] / leading_coeff))
    
    bound = 1 + max_ratio
    
    # Use bisection method to find a root
    # We need to find two points where the polynomial has opposite signs
    # Let's try expanding the search range if needed
    
    def bisect(a, b, tol=1e-10, max_iter=1000):
        fa = poly(xs, a)
        fb = poly(xs, b)
        
        if abs(fa) < tol:
            return a
        if abs(fb) < tol:
            return b
        
        if fa * fb > 0:
            return None
        
        for _ in range(max_iter):
            mid = (a + b) / 2
            fmid = poly(xs, mid)
            
            if abs(fmid) < tol or (b - a) / 2 < tol:
                return mid
            
            if fa * fmid < 0:
                b = mid
                fb = fmid
            else:
                a = mid
                fa = fmid
        
        return (a + b) / 2
    
    # Try to find a bracket for the root
    # Start with [-bound, bound]
    a, b = -bound, bound
    fa = poly(xs, a)
    fb = poly(xs, b)
    
    # If fa and fb have the same sign, we need to expand the range
    # For odd degree polynomials, as x -> +inf, poly(x) -> sign(leading_coeff) * inf
    # and as x -> -inf, poly(x) -> -sign(leading_coeff) * inf
    # So there must be a sign change somewhere
    
    if fa * fb > 0:
        # Expand the range
        for _ in range(100):
            a *= 2