def tri(n):
    """Everyone knows Fibonacci sequence, it was studied deeply by mathematicians in 
    the last couple centuries. However, what people don't know is Tribonacci sequence.
    Tribonacci sequence is defined by the recurrence:
    tri(1) = 3
    tri(n) = 1 + n / 2, if n is even.
    tri(n) =  tri(n - 1) + tri(n - 2) + tri(n + 1), if n is odd.
    For example:
    tri(2) = 1 + (2 / 2) = 2
    tri(4) = 3
    tri(3) = tri(2) + tri(1) + tri(4)
           = 2 + 3 + 3 = 8 
    You are given a non-negative integer number n, you have to a return a list of the 
    first n + 1 numbers of the Tribonacci sequence.
    Examples:
    tri(3) = [1, 3, 2, 8]
    """
    if n < 0:
        return []
    
    # We need to compute tri(0), tri(1), ..., tri(n)
    # Let's figure out tri(0):
    # The problem doesn't explicitly define tri(0), but from the example tri(3) = [1, 3, 2, 8], 
    # the first element (index 0) is 1. So tri(0) = 1.
    
    # Let's build the sequence iteratively.
    # For even n: tri(n) = 1 + n/2
    # For odd n: tri(n) = tri(n-1) + tri(n-2) + tri(n+1)
    # But tri(n+1) for odd n means n+1 is even, so tri(n+1) = 1 + (n+1)/2
    
    # So for odd n: tri(n) = tri(n-1) + tri(n-2) + (1 + (n+1)/2)
    
    result = []
    for i in range(n + 1):
        if i == 0:
            result.append(1)
        elif i == 1:
            result.append(3)
        elif i % 2 == 0:
            # even
            result.append(1 + i // 2)
        else:
            # odd, i >= 3
            # tri(i) = tri(i-1) + tri(i-2) + tri(i+1)
            # tri(i+1) is even, so tri(i+1) = 1 + (i+1)//2
            tri_i_plus_1 = 1 + (i + 1) // 2
            tri_i = result[i - 1] + result[i - 2] + tri_i_plus_1
            result.append(tri_i)
    
    return result