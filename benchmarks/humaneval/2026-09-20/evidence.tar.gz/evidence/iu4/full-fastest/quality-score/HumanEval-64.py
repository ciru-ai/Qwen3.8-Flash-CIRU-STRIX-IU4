def vowels_count(s):
    """Write a function vowels_count which takes a string representing
    a word as input and returns the number of vowels in the string.
    Vowels in this case are 'a', 'e', 'i', 'o', 'u'. Here, 'y' is also a
    vowel, but only when it is at the end of the given word.

    Example:
    >>> vowels_count("abcde")
    2
    >>> vowels_count("ACEDY")
    3
    """
    if not s:
        return 0
    
    vowels = 'aeiouAEIOU'
    count = 0
    
    for char in s:
        if char in vowels:
            count += 1
    
    # Check if 'y' or 'Y' is at the end of the string
    if s[-1] in 'yY':
        count += 1
    
    return count