def get_max_triples(n):
    """
    You are given a positive integer n. You have to create an integer array a of length n.
        For each i (1 ≤ i ≤ n), the value of a[i] = i * i - i + 1.
        Return the number of triples (a[i], a[j], a[k]) of a where i < j < k, 
    and a[i] + a[j] + a[k] is a multiple of 3.

    Example :
        Input: n = 5
        Output: 1
        Explanation: 
        a = [1, 3, 7, 13, 21]
        The only valid triple is (1, 7, 13).
    """
    # Compute a[i] for i from 1 to n
    # a[i] = i*i - i + 1
    # We need to count triples (i, j, k) with i < j < k such that a[i] + a[j] + a[k] % 3 == 0
    
    # Let's compute a[i] mod 3 for each i
    # a[i] = i^2 - i + 1
    # Let's compute i mod 3 and see what a[i] mod 3 is
    
    # For i mod 3 = 0: i = 3m, a[i] = 9m^2 - 3m + 1 ≡ 1 mod 3
    # For i mod 3 = 1: i = 3m+1, a[i] = (3m+1)^2 - (3m+1) + 1 = 9m^2 + 6m + 1 - 3m - 1 + 1 = 9m^2 + 3m + 1 ≡ 1 mod 3
    # For i mod 3 = 2: i = 3m+2, a[i] = (3m+2)^2 - (3m+2) + 1 = 9m^2 + 12m + 4 - 3m - 2 + 1 = 9m^2 + 9m + 3 ≡ 0 mod 3
    
    # So:
    # i ≡ 0 mod 3 => a[i] ≡ 1 mod 3
    # i ≡ 1 mod 3 => a[i] ≡ 1 mod 3
    # i ≡ 2 mod 3 => a[i] ≡ 0 mod 3
    
    # Let's verify with the example:
    # i=1: 1 mod 3 = 1, a[1] = 1, 1 mod 3 = 1 ✓
    # i=2: 2 mod 3 = 2, a[2] = 3, 3 mod 3 = 0 ✓
    # i=3: 3 mod 3 = 0, a[3] = 7, 7 mod 3 = 1 ✓
    # i=4: 4 mod 3 = 1, a[4] = 13, 13 mod 3 = 1 ✓
    # i=5: 5 mod 3 = 2, a[5] = 21, 21 mod 3 = 0 ✓
    
    # So we have two categories:
    # - Remainder 0: indices where i ≡ 2 mod 3
    # - Remainder 1: indices where i ≡ 0 or 1 mod 3
    
    # We need a[i] + a[j] + a[k] ≡ 0 mod 3
    # Possible combinations of remainders (r_i, r_j, r_k) that sum to 0 mod 3:
    # (0, 0, 0): sum = 0
    # (1, 1, 1): sum = 3 ≡ 0
    # (0, 1, 2): but we don't have remainder 2!
    # Wait, let me recheck. We only have remainders 0 and 1.
    # So possible triples of remainders that sum to 0 mod 3:
    # (0, 0, 0): 0+0+0 = 0 ✓
    # (1, 1, 1): 1+1+1 = 3 ≡ 0 ✓
    # (0, 0, 1): 0+0+1 = 1 ✗
    # (0