def circular_shift(x, shift):
    """Circular shift the digits of the integer x, shift the digits right by shift
    and return the result as a string.
    If shift > number of digits, return digits reversed.
    >>> circular_shift(12, 1)
    "21"
    >>> circular_shift(12, 2)
    "12"
    """
    s = str(x)
    n = len(s)
    if shift > n:
        return s[::-1]
    # Shift right by shift means the last 'shift' digits move to the front
    # e.g., 12345 shift 2 -> 45123
    # So we take the last 'shift' characters and put them in front
    shift = shift % n
    if shift == 0:
        return s
    return s[-shift:] + s[:-shift]