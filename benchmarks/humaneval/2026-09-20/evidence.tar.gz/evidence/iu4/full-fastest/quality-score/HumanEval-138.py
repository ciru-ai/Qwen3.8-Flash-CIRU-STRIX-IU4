def is_equal_to_sum_even(n):
    """Evaluate whether the given number n can be written as the sum of exactly 4 positive even numbers
    Example
    is_equal_to_sum_even(4) == False
    is_equal_to_sum_even(6) == False
    is_equal_to_sum_even(8) == True
    """
    # The smallest sum of 4 positive even numbers is 2+2+2+2 = 8
    # Any even number >= 8 can be written as the sum of 4 positive even numbers
    # Because if n is even and n >= 8, we can write n = 2 + 2 + 2 + (n-6)
    # where n-6 is even and >= 2 (since n >= 8)
    # If n is odd, it cannot be written as sum of even numbers
    # If n < 8, it cannot be written as sum of 4 positive even numbers
    if n < 8:
        return False
    if n % 2 != 0:
        return False
    return True