def find_max(words):
    """Write a function that accepts a list of strings.
    The list contains different words. Return the word with maximum number
    of unique characters. If multiple strings have maximum number of unique
    characters, return the one which comes first in lexicographical order.

    find_max(["name", "of", "string"]) == "string"
    find_max(["name", "enam", "game"]) == "enam"
    find_max(["aaaaaaa", "bb" ,"cc"]) == "aaaaaaa"
    """
    if not words:
        return ""
    
    # Find the maximum number of unique characters
    max_unique = max(len(set(word)) for word in words)
    
    # Filter words that have the maximum number of unique characters
    candidates = [word for word in words if len(set(word)) == max_unique]
    
    # Return the lexicographically smallest candidate
    return min(candidates)