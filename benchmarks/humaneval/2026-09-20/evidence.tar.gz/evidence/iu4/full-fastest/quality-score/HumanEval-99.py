def closest_integer(value):
    '''
    Create a function that takes a value (string) representing a number
    and returns the closest integer to it. If the number is equidistant
    from two integers, round it away from zero.

    Examples
    >>> closest_integer("10")
    10
    >>> closest_integer("15.3")
    15

    Note:
    Rounding away from zero means that if the given number is equidistant
    from two integers, the one you should return is the one that is the
    farthest from zero. For example closest_integer("14.5") should
    return 15 and closest_integer("-14.5") should return -15.
    '''
    import math
    
    num = float(value)
    
    # Check if the number is equidistant from two integers
    # This happens when the fractional part is exactly 0.5
    fractional_part = num - math.floor(num)
    
    # Handle negative numbers properly
    # For negative numbers, math.floor goes more negative
    # e.g., math.floor(-14.5) = -15, fractional_part = -14.5 - (-15) = 0.5
    
    if abs(fractional_part - 0.5) < 1e-9:
        # Equidistant case: round away from zero
        if num >= 0:
            return int(math.ceil(num))
        else:
            return int(math.floor(num))
    else:
        # Normal rounding: round to nearest integer
        # Python's round() does banker's rounding, so we need to be careful
        # Instead, let's use a manual approach
        if num >= 0:
            return int(math.floor(num + 0.5))
        else:
            return int(math.ceil(num - 0.5))