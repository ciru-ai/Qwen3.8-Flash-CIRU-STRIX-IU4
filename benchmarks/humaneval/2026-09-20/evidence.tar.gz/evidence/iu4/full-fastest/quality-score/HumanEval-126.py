def is_sorted(lst):
    '''
    Given a list of numbers, return whether or not they are sorted
    in ascending order. If list has more than 1 duplicate of the same
    number, return False. Assume no negative numbers and only integers.

    Examples
    is_sorted([5]) ➞ True
    is_sorted([1, 2, 3, 4, 5]) ➞ True
    is_sorted([1, 3, 2, 4, 5]) ➞ False
    is_sorted([1, 2, 3, 4, 5, 6]) ➞ True
    is_sorted([1, 2, 3, 4, 5, 6, 7]) ➞ True
    is_sorted([1, 3, 2, 4, 5, 6, 7]) ➞ False
    is_sorted([1, 2, 2, 3, 3, 4]) ➞ True
    is_sorted([1, 2, 2, 2, 3, 4]) ➞ False
    '''
    # Check if the list is sorted in ascending order
    for i in range(len(lst) - 1):
        if lst[i] > lst[i + 1]:
            return False
    
    # Check for duplicates: no number should appear more than once
    # Wait, let me re-read the problem. "If list has more than 1 duplicate of the same number, return False."
    # Looking at examples: [1, 2, 2, 3, 3, 4] returns True, so duplicates are allowed as long as each number appears at most twice?
    # No wait: [1, 2, 2, 2, 3, 4] returns False. So if any number appears more than 2 times, return False.
    # Actually, let me re-read: "If list has more than 1 duplicate of the same number" - this is ambiguous.
    # Looking at examples: [1, 2, 2, 3, 3, 4] has 2 appearing twice and 3 appearing twice, and it returns True.
    # [1, 2, 2, 2, 3, 4] has 2 appearing three times, and it returns False.
    # So the condition is: no number should appear more than 2 times.
    
    from collections import Counter
    counts = Counter(lst)
    for count in counts.values():
        if count > 2:
            return False
    
    return True