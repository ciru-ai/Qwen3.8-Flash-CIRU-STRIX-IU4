def is_multiply_prime(a):
    """Write a function that returns true if the given number is the multiplication of 3 prime numbers
    and false otherwise.
    Knowing that (a) is less then 100. 
    Example:
    is_multiply_prime(30) == True
    30 = 2 * 3 * 5
    """
    def is_prime(n):
        if n < 2:
            return False
        for i in range(2, int(n**0.5) + 1):
            if n % i == 0:
                return False
        return True
    
    # Find all primes less than 100
    primes = [p for p in range(2, 100) if is_prime(p)]
    
    # Check if a can be expressed as product of exactly 3 primes (with repetition allowed)
    for p1 in primes:
        if p1 > a:
            break
        for p2 in primes:
            if p1 * p2 > a:
                break
            for p3 in primes:
                product = p1 * p2 * p3
                if product == a:
                    return True
                if product > a:
                    break
    return False