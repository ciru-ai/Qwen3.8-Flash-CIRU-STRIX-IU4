def encode(message):
    """
    Write a function that takes a message, and encodes in such a 
    way that it swaps case of all letters, replaces all vowels in 
    the message with the letter that appears 2 places ahead of that 
    vowel in the english alphabet. 
    Assume only letters. 
    
    Examples:
    >>> encode('test')
    'TGST'
    >>> encode('This is a message')
    'tHKS KS C MGSSCGG'
    """
    vowels = 'aeiouAEIOU'
    result = []
    for char in message:
        if char in vowels:
            # Swap case first, then shift by 2
            swapped = char.swapcase()
            # Find the position in the alphabet and shift by 2
            # We need to handle both lowercase and uppercase
            if swapped.islower():
                new_char = chr(ord(swapped) + 2)
            else:
                new_char = chr(ord(swapped) + 2)
            result.append(new_char)
        else:
            result.append(char.swapcase())
    return ''.join(result)