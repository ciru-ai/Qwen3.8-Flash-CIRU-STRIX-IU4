import contextlib
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import signal
import statistics
import subprocess
import sys
import time
import types
import urllib.request

ROOT = Path(__file__).resolve().parent
BASE = 'http://127.0.0.1:18090'
PYTHON = '/srv/ssd/p3700ba/data/llm-benchmarking-lab/.venvs/quality-py311/bin/python'
ENGINE = Path('/srv/ssd/sn850x/data/llm/engines/Qwen3.8-Flash-CIRU-STRIX-v4.4.1')
MODEL = Path('/srv/llm/models/Qwen3.8-Flash-CIRU-STRIX-IU4/Qwen3.8-Flash-CIRU-STRIX-IU4.gguf')
PROFILE = Path('/home/crown/machine-setup/model-profiles/qwen3.8-flash-ciru-strix-iu4-v4.4.1-thinking-off-256k.env')
BENCH = Path('/home/crown/.codex/skills/llama-benchmark/scripts/llama_benchmark.py')
STORE = Path('/home/crown/bench-results/llama')
spec = importlib.util.spec_from_file_location('bench', BENCH)
bench = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bench)
TASKS = [json.loads(x) for x in (ROOT/'sources/HumanEvalPlus-v0.1.10.jsonl').read_text().splitlines()]
TASKS.sort(key=lambda x: int(x['task_id'].split('/')[1]))
SERVER = None
SERVER_LOG = None
RESULTS = []


def dump(path, value):
    path = Path(path)
    tmp = path.with_name(path.name+'.tmp')
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n')
    tmp.replace(path)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(16*1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def request(path, body=None):
    headers = {'Content-Type':'application/json'}
    if os.environ.get('LLAMA_API_KEY'):
        headers['Authorization'] = 'Bearer '+os.environ['LLAMA_API_KEY']
    req = urllib.request.Request(BASE+path, data=None if body is None else json.dumps(body).encode(), headers=headers)
    with urllib.request.urlopen(req, timeout=180) as response:
        return response.read()


def payload(task, model):
    return {'model':model, 'messages':[
        {'role':'system','content':'You are a helpful assistant good at coding.'},
        {'role':'user','content':'Please provide a self-contained Python script that solves the following problem in a markdown code block:\n```python\n'+task['prompt'].strip()+'\n```'}],
        'temperature':0.0,'max_tokens':1024,'n':1,'seed':0,'top_p':0.95,'top_k':20,'min_p':0.0,
        'repeat_penalty':1.0,'presence_penalty':0.0,'frequency_penalty':0.0,
        'chat_template_kwargs':{'enable_thinking':False},'stream':False,'cache_prompt':False,'id_slot':0}


def stop_server():
    global SERVER, SERVER_LOG
    if SERVER and SERVER.poll() is None:
        SERVER.terminate()
        try:
            SERVER.wait(timeout=45)
        except subprocess.TimeoutExpired:
            SERVER.kill()
            SERVER.wait()
    SERVER = None
    if SERVER_LOG:
        SERVER_LOG.close()
        SERVER_LOG = None


def run_arm(name, depth, boost, count=10, context=262144):
    global SERVER, SERVER_LOG
    arm = ROOT/name
    if (arm/'result.json').exists():
        result=json.loads((arm/'result.json').read_text())
        RESULTS.append(result)
        dump(ROOT/'results.json',RESULTS)
        print('REUSE valid unboosted depth screen',name,flush=True)
        return result
    arm.mkdir(exist_ok=False)
    gen = arm/'generation'
    gen.mkdir()
    (arm/'sources').mkdir()
    os.link(ROOT/'sources/HumanEvalPlus-v0.1.10.jsonl',arm/'sources/HumanEvalPlus-v0.1.10.jsonl')
    for file in ('score.py','score-sandbox.py'):
        shutil.copy2(ROOT/file,arm/file)
    cfg={'depth':depth,'boost':boost,'count':count,'context':context}
    dump(ROOT/'status.json', {'stage':'loading','arm':name,**cfg})
    print('LOAD',name,cfg,flush=True)
    SERVER_LOG=(arm/'server.log').open('w')
    SERVER=subprocess.Popen(['/run/current-system/sw/bin/bash',str(ROOT/'launch.sh'),str(depth),str(int(boost)),str(arm/'slot-state'),str(context)],stdout=SERVER_LOG,stderr=subprocess.STDOUT)
    ready=False
    for _ in range(300):
        if SERVER.poll() is not None:
            raise RuntimeError(f'{name}: server exit {SERVER.returncode}')
        try:
            if json.loads(request('/health'))['status']=='ok':
                ready=True
                break
        except Exception:
            time.sleep(2)
    assert ready, 'startup timeout'
    props=json.loads(request('/props'))
    slots=json.loads(request('/slots'))
    assert Path(props['model_path'])==MODEL
    assert len(slots)==1 and slots[0]['n_ctx']==context and slots[0]['speculative']
    argv=Path(f'/proc/{SERVER.pid}/cmdline').read_bytes().decode().split('\0')[:-1]
    assert argv[argv.index('--spec-draft-n-max')+1]==str(depth)
    assert ('--spec-ngram-mod-n-match' in argv)==boost
    env=dict(x.split(b'=',1) for x in Path(f'/proc/{SERVER.pid}/environ').read_bytes().split(b'\0') if b'=' in x)
    safe_names=['LLAMA_MTP_QSA_MIN_T','LLAMA_QSA_FA_V3','KAIRIC_BOOST','CIRU_MTP_SHORTLIST','ROCM_PATH','LD_LIBRARY_PATH']
    dump(arm/'runtime-env.json',{x:env.get(x.encode(),b'').decode() for x in safe_names})
    dump(arm/'command.json',argv)
    dump(gen/'props-before.json',props)
    dump(gen/'slots-before.json',slots)
    dump(arm/'protocol.lock.json',{'classification':'local-custom','config':cfg,'identity':json.loads((ROOT/'identity.json').read_text()),
        'command':argv,'template_sha256':hashlib.sha256(props['chat_template'].encode()).hexdigest(),
        'sampler_example':payload(TASKS[0],props['model_alias']),'generator_sha256':sha(__file__),'protocol_sha256':sha(ROOT/'PROTOCOL.md')})
    # Exercise the official streamed measurement path once, excluded from every panel.
    warm=payload(TASKS[0],props['model_alias'])
    warm['messages'][1]['content']='Write a Python function named ciru_warmup_affine_917(x) that returns 11*x+29. Return only its code.'
    dump(arm/'warmup-messages.json',warm['messages'])
    rendered=json.loads(request('/apply-template',{'messages':warm['messages'],'chat_template_kwargs':warm['chat_template_kwargs'],'add_generation_prompt':True}))
    if count==164 and context<262144:
        lengths=[]
        for task in TASKS:
            body=payload(task,props['model_alias'])
            text=json.loads(request('/apply-template',{'messages':body['messages'],'chat_template_kwargs':body['chat_template_kwargs'],'add_generation_prompt':True}))['prompt']
            token_count=len(json.loads(request('/tokenize',{'content':text,'add_special':True}))['tokens'])
            assert token_count+1024<=context,(task['task_id'],token_count,context)
            lengths.append({'task_id':task['task_id'],'prompt_tokens':token_count})
        dump(arm/'context-fit.json',lengths)
    (arm/'warmup-prompt.txt').write_text(rendered['prompt'])
    bench.http_get=lambda url: request(url.removeprefix(BASE)).decode()
    args=types.SimpleNamespace(out_dir=str(STORE),label='iu4-he-tune-'+name+'-excluded-warmup',base_url=BASE,
        prompt_file=str(arm/'warmup-prompt.txt'),gen=1024,disable_prompt_cache=True,ignore_eos=False,
        payload_json=json.dumps({'temperature':0,'seed':0,'top_p':0.95,'top_k':20,'min_p':0,'repeat_penalty':1,'presence_penalty':0,'frequency_penalty':0}),
        api_key=os.environ.get('LLAMA_API_KEY'),timeout=180,sample_interval=.5,model=str(MODEL))
    with (arm/'warmup-row.json').open('w') as out,contextlib.redirect_stdout(out):
        assert bench.api(args)==0
    (gen/'metrics-before.txt').write_bytes(request('/metrics'))
    rows=[]
    for i,task in enumerate(TASKS[:count]):
        case=gen/task['task_id'].replace('/','-')
        case.mkdir()
        req=payload(task,props['model_alias'])
        dump(case/'request.json',req)
        assert not json.loads(request('/slots'))[0]['is_processing']
        with bench.Sampler(.5) as sampler:
            started=time.perf_counter()
            raw=request('/v1/chat/completions',req)
            elapsed=time.perf_counter()-started
        (case/'response.json').write_bytes(raw)
        response=json.loads(raw)
        choice=response['choices'][0]
        content=choice['message'].get('content') or ''
        reasoning=choice['message'].get('reasoning_content') or choice['message'].get('reasoning') or ''
        (case/'completion.txt').write_text(content)
        assert not reasoning and content
        memory=sampler.summary()
        dump(case/'memory-samples.json',sampler.samples)
        row={'task_id':task['task_id'],'wall_seconds':elapsed,'finish_reason':choice['finish_reason'],
            'reasoning_characters':len(reasoning),'usage':response['usage'],'timings':response['timings'],
            'output_sha256':hashlib.sha256(content.encode()).hexdigest(),'memory':memory}
        assert row['usage']['completion_tokens']<=1024
        rows.append(row)
        dump(gen/'progress.json',{'completed':len(rows),'total':count,'rows':rows})
        durable={'kind':'llama-server-api','label':f'iu4-he-tune-{name}-{i}','timestamp_utc':bench.now_slug(),'mode':'tg',
            'model':str(MODEL),'ctx':row['usage']['prompt_tokens'],'gen':row['usage']['completion_tokens'],
            'avg_tps':row['timings']['predicted_per_second'],'total_ms':elapsed*1000,'ttfp_ms':None,
            'timings':row['timings'],'memory':memory,'backend':'ROCm10 gfx1151',
            'raw_output':str(case/'response.json'),'samples':str(case/'memory-samples.json'),'server_props':props,
            'generation_settings':req,'settings_json':{'command':argv,'depth':depth,'boost':boost,'allocated_context':context},
            'metadata_quality':'full','harness':'local-custom-nonstream-chat','error':None}
        bench.store_rows(STORE,[durable])
        dump(ROOT/'status.json',{'stage':'generation','arm':name,'completed':len(rows),'total':count})
        print(name,f'{i+1}/{count}',f'{elapsed:.3f}s',choice['finish_reason'],flush=True)
    dump(gen/'slots-after.json',json.loads(request('/slots')))
    (gen/'metrics-after.txt').write_bytes(request('/metrics'))
    times=[r['wall_seconds'] for r in rows]
    summary={'completed':len(rows),'total_wall_seconds':sum(times),'mean_wall_seconds':statistics.mean(times),'median_wall_seconds':statistics.median(times),'rows':rows}
    dump(gen/'summary.json',summary)
    stop_server()
    dump(ROOT/'status.json',{'stage':'scoring','arm':name})
    with (arm/'scoring-driver.log').open('w') as log:
        subprocess.run([PYTHON,str(ROOT/'score-sandbox.py'),str(arm)],stdout=log,stderr=subprocess.STDOUT,timeout=1800,check=True)
    quality=json.loads((arm/'quality-score/summary.json').read_text())
    valid=quality['base_pass']==count and quality['plus_pass']==count and quality['length_finishes']==0
    result={'name':name,**cfg,'wall_seconds':sum(times),'mean_seconds':statistics.mean(times),'median_seconds':statistics.median(times),
        'decode_tps':sum(r['timings']['predicted_n'] for r in rows)/(sum(r['timings']['predicted_ms'] for r in rows)/1000),
        'prompt_tps':sum(r['timings']['prompt_n'] for r in rows)/(sum(r['timings']['prompt_ms'] for r in rows)/1000),
        'acceptance':sum(r['timings'].get('draft_n_accepted',0) for r in rows)/max(1,sum(r['timings'].get('draft_n',0) for r in rows)),
        'tokens':sum(r['usage']['completion_tokens'] for r in rows),'quality':quality,'eligible':valid,
        'output_hashes':[r['output_sha256'] for r in rows]}
    dump(arm/'result.json',result)
    RESULTS.append(result)
    dump(ROOT/'results.json',RESULTS)
    print('RESULT',json.dumps({k:v for k,v in result.items() if k!='output_hashes'}),flush=True)
    return result


def main():
    was_active=subprocess.run(['systemctl','--user','is-active','--quiet','qwen-main.service']).returncode==0
    before=subprocess.run(['systemctl','--user','is-enabled','qwen-main.service'],capture_output=True,text=True).stdout.strip()
    dump(ROOT/'service-before.json',{'active':was_active,'enabled':before})
    try:
        print('Hashing frozen model and runtime identity',flush=True)
        files=[MODEL,MODEL.parent/'mtp/Qwen3.8-Flash-CIRU-STRIX-IU4-MTP-Q8_0.gguf',ENGINE/'bin/llama-server',ENGINE/'bin/libllama.so',ENGINE/'bin/libggml-hip.so',PROFILE,ROOT/'sources/HumanEvalPlus-v0.1.10.jsonl',BENCH]
        old=json.loads((ROOT/'identity.json').read_text()) if (ROOT/'identity.json').exists() else {}
        identity={str(p):(old[str(p)] if str(p) in old and old[str(p)]['bytes']==p.stat().st_size and p.stat().st_mtime < (ROOT/'identity.json').stat().st_mtime else {'bytes':p.stat().st_size,'sha256':sha(p)}) for p in files}
        dump(ROOT/'identity.json',identity)
        subprocess.run(['systemctl','--user','stop','qwen-main.service'],check=True)
        baseline=run_arm('screen-d3',3,False)
        assert baseline['eligible'],'baseline did not pass all ten tests'
        run_arm('screen-d4',4,False)
        six=run_arm('screen-d6',6,False)
        eight=run_arm('screen-d8',8,False)
        if eight['eligible'] and eight['wall_seconds'] < six['wall_seconds']*.98:
            run_arm('screen-d12',12,False)
        best=min((r for r in RESULTS if r['eligible']),key=lambda r:r['wall_seconds'])
        boosted=run_arm(f'screen-d{best["depth"]}-boost',best['depth'],True)
        if boosted['eligible'] and boosted['wall_seconds'] < best['wall_seconds']*.98:
            lower=max((r['depth'] for r in RESULTS if not r['boost'] and r['depth']<best['depth']),default=0)
            if lower:
                run_arm(f'screen-d{lower}-boost',lower,True)
        lead=min((r for r in RESULTS if r['eligible']),key=lambda r:r['wall_seconds'])
        dump(ROOT/'screen-decision.json',{'baseline':baseline,'lead':lead,'stage':'confirm independent loads'})
        mirrors=[]
        validation=[]
        for block in range(1):
            if block==1:
                pooled=100*(1-math.sqrt((validation[1]['wall_seconds']*validation[2]['wall_seconds'])/(validation[0]['wall_seconds']*validation[3]['wall_seconds'])))
                noisy=mirrors[0]*mirrors[1]<0 or abs(mirrors[0]-mirrors[1])>3 or abs(pooled-2)<.5
                if not noisy:
                    break
            a1=run_arm(f'confirm-{block}-a1',3,False)
            c1=run_arm(f'confirm-{block}-c1',lead['depth'],lead['boost'])
            c2=run_arm(f'confirm-{block}-c2',lead['depth'],lead['boost'])
            a2=run_arm(f'confirm-{block}-a2',3,False)
            validation.extend([a1,c1,c2,a2])
            mirrors.extend([100*(1-c1['wall_seconds']/a1['wall_seconds']),100*(1-c2['wall_seconds']/a2['wall_seconds'])])
            if not all(r['eligible'] for r in validation):
                break
        pooled=100*(1-math.prod(1-x/100 for x in mirrors)**(1/len(mirrors)))
        confirmed=all(r['eligible'] for r in validation) and all(x>0 for x in mirrors) and pooled>=2
        chosen=lead if confirmed else baseline
        decision={'chosen_depth':chosen['depth'],'boost':chosen['boost'],'confirmed_speed_win':confirmed,
            'mirrored_wall_reductions_percent':mirrors,'pooled_wall_reduction_percent':pooled,
            'decision':'PROMOTE to full suite' if confirmed else 'PRACTICAL_PARITY_OR_UNCONFIRMED: full suite with baseline',
            'scope':'HE0-9 local-custom short coding only; no production-default promotion'}
        dump(ROOT/'winner.json',decision)
        print('WINNER',json.dumps(decision),flush=True)
        large1=next(r for r in reversed(validation) if r['depth']==chosen['depth'] and r['boost']==chosen['boost'])
        small1=run_arm('context-small-1',chosen['depth'],chosen['boost'],context=4096)
        cm=[100*(1-small1['wall_seconds']/large1['wall_seconds'])]
        cp=cm[0]
        cv=small1['eligible'] and cp>0
        decision['context']=4096 if cv else 262144
        decision['context_test']={'mirrors_percent':cm,'pooled_reduction_percent':cp,'promoted':cv,
            'design':'User-amended bounded smoke: one 4K run versus most recent matching 256K confirmation; fastest quality-passing observed context selected.',
            'reference_arm':large1['name'],'small_arm':small1['name']}
        dump(ROOT/'winner.json',decision)
        print('CONTEXT WINNER',json.dumps(decision),flush=True)
        full=run_arm('full-fastest',chosen['depth'],chosen['boost'],164,context=decision['context'])
        dump(ROOT/'complete.json',{'winner':decision,'full':full})
    finally:
        stop_server()
        if was_active:
            subprocess.run(['systemctl','--user','start','qwen-main.service'],check=True)
        after=subprocess.run(['systemctl','--user','is-enabled','qwen-main.service'],capture_output=True,text=True).stdout.strip()
        dump(ROOT/'restoration.json',{'was_active':was_active,'active':subprocess.run(['systemctl','--user','is-active','--quiet','qwen-main.service']).returncode==0,
            'enabled_before':before,'enabled_after':after,'same_enabled_state':before==after})


if __name__=='__main__':
    signal.signal(signal.SIGTERM,lambda *_:sys.exit(143))
    main()
