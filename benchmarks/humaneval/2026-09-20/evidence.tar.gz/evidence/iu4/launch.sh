#!/usr/bin/env bash
set -euo pipefail
set -a
source /home/crown/machine-setup/model-profiles/qwen3.8-flash-ciru-strix-iu4-v4.4.1-thinking-off-256k.env
set +a
export MTP_DRAFT_N_MAX="$1" KAIRIC_BOOST="$2"
export HOST=127.0.0.1 PORT=18090 PUBLIC_ALIAS=Qwen3.8-Flash-CIRU-STRIX-IU4
export SLOT_SAVE_PATH="$3"
export MODEL_CONTEXT="${4:-262144}"
exec /home/crown/machine-setup/launch-qwen38-flash-v4.4.1.sh
