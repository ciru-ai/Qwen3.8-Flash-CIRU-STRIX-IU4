"""Run only in the per-run Bubblewrap sandbox."""
import ast
import hashlib
import json
import time
from pathlib import Path
from evalplus.data import get_human_eval_plus
from evalplus.evaluate import check_correctness, get_groundtruth
from evalplus.sanitize import sanitize


def main():
    count = json.loads(Path("/input/generation/summary.json").read_text())["completed"]
    tasks = {k:v for k,v in get_human_eval_plus(version="v0.1.10").items() if int(k.split("/")[1]) < count}
    dataset = Path("/tmp/cache/evalplus/HumanEvalPlus-v0.1.10.jsonl")
    ground = get_groundtruth(tasks, "orca-reddit-" + hashlib.sha256(dataset.read_bytes()).hexdigest(), [])
    rows = []
    output = Path("/output")
    output.mkdir(exist_ok=True)
    for i in range(count):
        deadline = time.monotonic() + 900
        while True:
            try:
                completed = json.loads(Path('/input/generation/progress.json').read_text())['completed']
            except (FileNotFoundError, json.JSONDecodeError):
                completed = 0
            if completed > i:
                break
            if time.monotonic() > deadline:
                raise TimeoutError(f'No completed generation for HumanEval/{i}')
            time.sleep(1)
        task = tasks[f"HumanEval/{i}"]
        case = Path(f"/input/generation/HumanEval-{i}")
        raw = (case / "completion.txt").read_text()
        response = json.loads((case / "response.json").read_text())
        finish = response["choices"][0]["finish_reason"]
        code = sanitize(raw, entrypoint=task["entry_point"])
        (output / f"HumanEval-{i}.py").write_text(code)
        try:
            ast.parse(code)
            syntax_error = None
        except SyntaxError as exc:
            syntax_error = str(exc)
        row = check_correctness("humaneval", 0, task, code, ground[task["task_id"]],
                                fast_check=False, min_time_limit=1.0, gt_time_limit_factor=4.0)
        row["finish_reason"] = finish
        row["syntax_error"] = syntax_error
        row["base_pass"] = row["base"][0] == "pass"
        row["plus_pass"] = row["base_pass"] and row["plus"][0] == "pass"
        rows.append(row)
        (output / "scores.json").write_text(json.dumps(rows, indent=2, default=lambda x: x.tolist()) + "\n")
        print(task["task_id"], row["base"][0], row["plus"][0], finish, flush=True)
    summary = {"tasks": len(rows), "base_pass": sum(r["base_pass"] for r in rows),
               "plus_pass": sum(r["plus_pass"] for r in rows),
               "length_finishes": sum(r["finish_reason"] == "length" for r in rows),
               "strict_complete_base_pass": sum(r["base_pass"] and r["finish_reason"] == "stop" for r in rows),
               "strict_complete_plus_pass": sum(r["plus_pass"] and r["finish_reason"] == "stop" for r in rows),
               "base_failures": [r["task_id"] for r in rows if not r["base_pass"]],
               "plus_failures": [r["task_id"] for r in rows if not r["plus_pass"]]}
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
