import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(sys.argv[1]).resolve()
VENV = Path('/srv/ssd/p3700ba/data/llm-benchmarking-lab/.venvs/quality-py311')
LIB = '/nix/store/chqq8mpmpyfi9kgsngya71akv5xicn03-gcc-15.2.0-lib/lib'
OUT = ROOT / 'quality-score'


def main():
    OUT.mkdir(exist_ok=False)
    args = [
        'bwrap', '--unshare-all', '--die-with-parent', '--new-session',
        '--ro-bind', '/nix/store', '/nix/store',
        '--ro-bind', str(VENV), str(VENV),
        '--dir', '/input', '--ro-bind', str(ROOT/'generation'), '/input/generation',
        '--ro-bind', str(ROOT/'score.py'), '/input/score.py',
        '--bind', str(OUT), '/output', '--tmpfs', '/tmp',
        '--dir', '/tmp/cache', '--dir', '/tmp/cache/evalplus',
        '--ro-bind', str(ROOT/'sources/HumanEvalPlus-v0.1.10.jsonl'), '/tmp/cache/evalplus/HumanEvalPlus-v0.1.10.jsonl',
        '--proc', '/proc', '--dev', '/dev', '--chdir', '/tmp', '--clearenv',
        '--setenv', 'HOME', '/tmp', '--setenv', 'XDG_CACHE_HOME', '/tmp/cache',
        '--setenv', 'OMP_NUM_THREADS', '1', '--setenv', 'OPENBLAS_NUM_THREADS', '1',
        '--setenv', 'PATH', str(VENV/'bin'), '--setenv', 'LD_LIBRARY_PATH', LIB,
        str(VENV/'bin/python'), '/input/score.py',
    ]
    lock = {'argv': args, 'evalplus_version': importlib.metadata.version('evalplus'),
            'python_version': sys.version, 'files': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
            for p in [ROOT/'score.py', ROOT/'score-sandbox.py', ROOT/'sources/HumanEvalPlus-v0.1.10.jsonl']}}
    (OUT/'protocol.lock.json').write_text(json.dumps(lock, indent=2)+'\n')
    with (OUT/'score.log').open('w') as log:
        result = subprocess.run(args, stdout=log, stderr=subprocess.STDOUT, timeout=1800)
    print((OUT/'score.log').read_text()[-3000:], flush=True)
    sys.exit(result.returncode)


if __name__ == '__main__':
    main()
